<?php include('include/home/header.php'); ?>
		 
	 <div id="contact-page" class="container">
	 
    	<div class="bg">
	    	<div class="row">  			
	    		<div class="col-sm-12"> 				
					<div class="list-group">
                               <center><a href="#" class="list-group-item active"><h4 class="text-center"><i class="fa fa-check-circle fa-lg"></i> Your order has been submitted! Thank you for Shopping!<br />
					   Kindly help to complete this survey . This survey is meant to capture what different people understand about, e-commerce. <br/><span style="color:red;">All field are required<span/>.
					   </h4></a></center>
                            </div>    			    				    				
					
				</div>			 		
			</div> 
				<?php include('include/home/sidebar.php'); ?>                			
    		<div class="row">  	
	    		<div class="col-sm-8">
	    			<div class="contact-form">
	    				<div class="status alert alert-success" style="display: none"></div>
				    	<form id="main-contact-form" class="contact-form row" name="contact-form" method="post" action="qst.php">
				            <span> 1 &nbsp;<span><label class='text-primary'>Do you know any purchasing platform such as Jumia, Amazon,OLX etc </label>	
				<input type="radio" class="flat" name="platform"  value="yes" />Yes
				<input type="radio" class="flat" name="platform"  value="No" />No	<br/>
				<span> 2 &nbsp;<span><label class='text-primary'>Have you ever use any of this platform i.e Jumia, Amazon,OLX etc </label>	
				<input type="radio" class="flat" name="use"  value="yes"  />Yes
				<input type="radio" class="flat" name="use"  value="No" />No	<br/>
				<span> 3 &nbsp;<span><label class='text-primary'>How often do you make purchase online? </label>	
				<input type="radio" class="flat" name="often"  value="regular"  />Regular
				<input type="radio" class="flat" name="often"  value="rarely" />Rarely
				<input type="radio" class="flat" name="often"  value="to-some-extended"/>To some extended
				<input type="radio" class="flat" name="often"  value="never" />Never<br/>
                <span> 4 &nbsp;<span><label class='text-primary'>How long do you spent online a day? </label>
				<input type="radio" name="hrs"  value="3hrs" class="flat" />3hrs and bellow 
				<input type="radio" name="hrs"  value="5hrs" class="flat" /> 5-8hrs
				<input type="radio" name="hrs"  value="10hrs" class="flat" />10hrs and above<br />
				<span> 5 &nbsp;<span><label class='text-primary'>I know what to look for when going  online </label>
				<input type="radio" name="look"  value="yes" class="flat" />Yes
				<input type="radio" name="look"  value="not-really" class="flat" /> Not really
				<input type="radio" name="look"  value="rarely" class="flat" />Rarely
				<input type="radio" name="look"  value="no" class="flat" />No<br />
				<span> 6 &nbsp;<span><label class='text-primary'>I seek guidance on how to you use online platform</label>
				<input type="radio" name="guidance"  value="yes" class="flat" />Yes
				<input type="radio" name="guidance"  value="not-really" class="flat" /> Not really
				<input type="radio" name="guidance"  value="rarely" class="flat" />Rarely
				<input type="radio" name="guidance"  value="no" class="flat" />No<br />
				<span> 7 &nbsp;<span><label class='text-primary'>Online purchasing is the easiest methods of making orders. </label>	
				<input type="radio" name="easy"  value="yes" class="flat" />Yes
				<input type="radio" name="easy"  value="not-really" class="flat" /> Not really
				<input type="radio" name="easy"  value="complicate" class="flat" />Complicate
				<input type="radio" name="easy"  value="no" class="flat" />No<br />
				<span> 8 &nbsp;<span><label class='text-primary'>Online purchaisng is too complicate platform </label>
				<input type="radio" name="complicate"  value="yes" class="flat" />Yes
				<input type="radio" name="complicate"  value="not-really" class="flat" /> Not really				
				<input type="radio" name="complicate"  value="no" class="flat" />No<br />
				<span> 9 &nbsp;<span><label class='text-primary'>I find better deals when using online </label>
				<input type="radio" name="better"  value="yes" class="flat" />Yes
				<input type="radio" name="better"  value="not-really" class="flat" /> Not really
				<input type="radio" name="better"  value="rarely" class="flat" />Rarely
				<input type="radio" name="better"  value="no" class="flat" />No<br />
				<span> 10 &nbsp;<span><label class='text-primary'>It is very easy to locate a product when using online platform</label>
				<input type="radio" name="locate"  value="yes" class="flat" />Yes
				<input type="radio" name="locate"  value="some-how-easy" class="flat" /> Some how Easy
				<input type="radio" name="locate"  value="difficult" class="flat" />Difficult
				<input type="radio" name="locate"  value="some-how-difficult" class="flat" /> Some how Difficult<br />
				<span> 11 &nbsp;<span><label class='text-primary'>Online purchase is the most reliable method of buying products</label>
				<input type="radio" class="flat" name="reliable"  value="yes" />Yes
				<input type="radio" class="flat" name="reliable"  value="no" />No<br/>
				<span> 12 &nbsp;<span><label class='text-primary'>I do understand the risk with the use of online platform </label>
				<input type="radio" class="flat" name="risk"  value="yes"  />Yes
				<input type="radio" name="risk"  value="not-really" class="flat" /> Not really
				<input type="radio" class="flat" name="risk"  value="no" />No<br/>
				<span> 13 &nbsp;<span><label class='text-primary'>What do you like most like most with the use online purchasing</label>
				<input type="radio" name="like"  value="responsivenes" class="flat" />Responsivenes
				<input type="radio" name="like"  value="reliability" class="flat" /> Reliability
				<input type="radio" name="like"  value="conveniency" class="flat" /> Conveniency<br/>
				<span> 14 &nbsp;<span><label class='text-primary'>Which products do you mostly buy online </label>
				<input type="radio" class="flat" name="product"  value="electronics"  />Electronics
				<input type="radio" class="flat" name="product"  value="cloths" />Cloths
				<input type="radio" class="flat" name="product"  value="grocery" />grocery
				<input type="radio" class="flat" name="product"  value="furniture" />Furnitures
				<input type="radio" class="flat" name="product"  value="salon" />Hair products<br/>				
				<span> 15 &nbsp;<span><label class='text-primary'>Have use this online platform to purchase products </label>
				<input type="checkbox" name="online"  value="amazon" class="flat" />Amazon
				<input type="checkbox" name="online"  value="Jumia" class="flat" />Jumia
				<input type="checkbox" name="online "  value="olx" class="flat"/>OLX
				<input type="checkbox" name="online"  value="debonairs" class="flat" />Debonairs Pizza
				<input type="checkbox" name="online"  value="ALL" class="flat" /> 	All
				<input type="checkbox" name="online"  value="none" class="flat" /> None<br/>
				<span> 16 &nbsp;<span><label class='text-primary'>My first experence with the use of online platform</label>
				<input type="radio" class="flat" name="experence"  value="like" />I like it
				<input type="radio" class="flat" name="experence"  value="dislike" />Dislike
				<input type="radio" class="flat" name="experence"  value="difficult" />very difficult<br/>					
				<span> 17 &nbsp;<span><label class='text-primary'>My gender</label> 
				<input type="radio" class="flat" name="gender"  value="Male"  />Male
				<input type="radio" class="flat" name="gender"  value="Female" />Female<br/>
				<span> 18 &nbsp;<span><label class='text-primary'>My age bracket</label>
				<input type="radio" name="age"  value="youth" class="flat" />25yrs bellow 
				<input type="radio" name="age"  value="middle-age" class="flat" /> 26-35yrs
				<input type="radio" name="age"  value="old-age" class="flat" />36-50yrs
				<input type="radio" name="age"  value="aging" class="flat" />51yrs above 	
					<input type="submit" name="submit" class="btn btn-success pull-right" value="Submit">
				        </form>
	    			</div>
	    		</div>   			
	    	</div>  
    	</div>	
    </div><!--/#contact-page-->
	<?php include('include/home/footer.php'); ?>