 <?php include ('db.php'); 
 
	$q1=mysql_real_escape_string($_POST['platform']);
	$q2=mysql_real_escape_string($_POST['use']);
	$q3=mysql_real_escape_string($_POST['often']);
	$q4=mysql_real_escape_string($_POST['hrs']);
	$q5=mysql_real_escape_string($_POST['look']);
	$q6=mysql_real_escape_string($_POST['guidance']);
	$q7=mysql_real_escape_string($_POST['easy']);
	$q8=mysql_real_escape_string($_POST['complicate']);
	$q9=mysql_real_escape_string($_POST['better']);
	$q10=mysql_real_escape_string($_POST['locate']);
	$q11=mysql_real_escape_string($_POST['reliable']);
	$q12=mysql_real_escape_string($_POST['risk']);
	$q13=mysql_real_escape_string($_POST['like']);
	$q14=mysql_real_escape_string($_POST['product']);
	$q15=mysql_real_escape_string($_POST['online']);
	$q16=mysql_real_escape_string($_POST['experence']);
	$q17=mysql_real_escape_string($_POST['gender']);
	$q18=mysql_real_escape_string($_POST['age']);
	
	////Add message into the database
					mysql_query("INSERT INTO questionnaire(q1, q2, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18) VALUES('$q1', '$q2', '$q3', '$q4', '$q5', '$q6', '$q7', '$q8', '$q9', '$q10', '$q11', '$q12', '$q13', '$q14', '$q15', '$q16', '$q17', '$q18')") or die (mysql_error());
					header("location: finish.php?Message sent successful!");
					
	 ?>
	 