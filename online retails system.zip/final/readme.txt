Hello
Online M-shops is  an example of simple online retail shop.
Also this project is licenced for General public use: So feel free to edit or customize to suite your project.
Incase of difficult or Inqury contact on Email:festo782@gmail.com

It is develop using several programming language to enhance ropustness and security purpose
Layout structure.
HTML5-Web content and structure, 
CSS-For styling and cascading
Javascript-For text formatting and validations
JQuery-for slide shows and device responsiviness
Boostraps-Pops ups and modals
PHP object oriented -Security purpose 
Mysqli-For Advance security purpose
Msql-For database 


How they work
They have four (4) main modules
1. customers
2.Supplier
3.Admin

* Customers can access the following section
 i.Profile section
 ii.Ordering section
 iii.Order tracking 
 iv Make inquiry
 
 * Supplier can access the following section
 i. Add product
 ii.View reports
 iii.View customers orders
 
 *Admin control system functions
i. Add stocks
ii.Add users
iii.Direct sales
iv.View reports
etc

System Configuration:
Database name:sales
Username:root
Password:

How to access the system.
Customer profile:
username:festo
password:1234

Supplier profile
username:boss
password:1234

Admin profile
username:admin
Password:admin
password:1234

N/P: To login  to the system you use the same interface for all users: click login button on the home page thats login_.php



