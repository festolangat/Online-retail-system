/*
Navicat MySQL Data Transfer

Source Server         : mysql_conn
Source Server Version : 50624
Source Host           : localhost:3306
Source Database       : sales

Target Server Type    : MYSQL
Target Server Version : 50624
File Encoding         : 65001

Date: 2017-06-01 20:43:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `category`
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES ('1', 'Braids');
INSERT INTO `category` VALUES ('2', 'Necklaces');
INSERT INTO `category` VALUES ('4', 'Earings');
INSERT INTO `category` VALUES ('5', 'Perfumes');
INSERT INTO `category` VALUES ('6', 'Make up');

-- ----------------------------
-- Table structure for `collection`
-- ----------------------------
DROP TABLE IF EXISTS `collection`;
CREATE TABLE `collection` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  `balance` int(11) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of collection
-- ----------------------------

-- ----------------------------
-- Table structure for `customer`
-- ----------------------------
DROP TABLE IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `membership_number` varchar(100) NOT NULL,
  `prod_name` varchar(550) NOT NULL,
  `expected_date` varchar(500) NOT NULL,
  `note` varchar(500) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of customer
-- ----------------------------
INSERT INTO `customer` VALUES ('15', 'Mwangi', 'TRM', '12345', '100', 'Dawanol', '2017-01-21', 'Urgently');

-- ----------------------------
-- Table structure for `message`
-- ----------------------------
DROP TABLE IF EXISTS `message`;
CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(250) NOT NULL,
  `message` varchar(250) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of message
-- ----------------------------
INSERT INTO `message` VALUES ('8', 'mercy cheptoo', 'merci@gmail.com', 'order inquiry', 'latest date of order receiving', '2017-05-14');

-- ----------------------------
-- Table structure for `m_order`
-- ----------------------------
DROP TABLE IF EXISTS `m_order`;
CREATE TABLE `m_order` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `item` text NOT NULL,
  `amount` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `dateOrdered` varchar(100) NOT NULL,
  `dateDelivered` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of m_order
-- ----------------------------

-- ----------------------------
-- Table structure for `products`
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_code` varchar(200) NOT NULL,
  `gen_name` varchar(200) NOT NULL,
  `product_name` varchar(200) NOT NULL,
  `imgUrl` varchar(100) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `cost` varchar(100) NOT NULL,
  `o_price` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `supplier` varchar(100) NOT NULL,
  `onhand_qty` int(10) NOT NULL,
  `qty` int(10) NOT NULL,
  `qty_sold` int(10) NOT NULL,
  `expiry_date` varchar(500) NOT NULL,
  `date_arrival` varchar(500) NOT NULL,
  `view` int(100) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES ('61', 'Pressed podwer', 'PP', 'Mineral and white in color.\r\nThey are design for morning shores and after bath for body cool and nourish all day long', 'mineral pressed powder.jpg', 'Make up', '', '500', '800', '300', 'Turkey deallers', '0', '12', '12', '12-03-2019', 'Feb-03-2017', '1');
INSERT INTO `products` VALUES ('62', 'Gel Eyeliner', 'GE', 'For softening the skins. All type and colors available ', 'Gel eyeliner.jpg', 'Make up', '', '500', '890', '390', 'Seven Seas suppliers', '0', '9', '15', '7-03-2037', 'Feb-03-2017', null);
INSERT INTO `products` VALUES ('63', 'Skins Brushes', 'SB', ' All size and shape available ', 'professional Quality Brushes.jpg', 'Make up', '', '700', '1200', '500', 'Turbo and Herbal beauty products', '0', '4', '10', '', '', null);
INSERT INTO `products` VALUES ('64', 'Angel spray', 'AS', ' Quality Braids .Available All size and shape', 'Angel.jpg', 'Braids', '', '100', '150', '50', 'Turkey deallers', '0', '90', '90', 'Feb-03-2080', '10-03-2017', '8');
INSERT INTO `products` VALUES ('65', 'Abuja Braids', 'AB', 'New fashion of braids with radiant technology for hair maintenance.', 'Abuja.jpg', 'Braids', '', '100', '200', '100', 'Seven Seas suppliers', '0', '60', '60', 'Feb-03-2019', '12-03-2017', '1');
INSERT INTO `products` VALUES ('66', 'Queen Braids', 'QB', ' All size and color available', 'Queen Queen.jpg', 'Braids', '', '50', '150', '100', 'Turbo and Herbal beauty products', '0', '100', '100', 'Feb-03-2025', '10-03-2017', null);
INSERT INTO `products` VALUES ('67', 'Silver Necklace', 'SN', ' Import from dubai .Original products', 'Silver Metal Green and Blue Glass.jpg', 'Necklaces', '', '7500', '15000', '7500', 'Turkey deallers', '0', '10', '12', 'Feb-03-2023', '12-03-2017', '2');
INSERT INTO `products` VALUES ('68', 'Venetian Necklace', 'VN', 'Shinny and briskly type from china ', 'Venetian-Box-chain necklace.jpg', 'Necklaces', '', '6000', '12000', '6000', 'Seven Seas suppliers', '0', '9', '5', '', '', null);
INSERT INTO `products` VALUES ('69', 'Auriya Gold Necklace', 'AG', ' Brown and silver color available', 'Auriya 14k Gold.jpg', 'Necklaces', '', '12000', '20000', '8000', 'Turbo and Herbal beauty products', '0', '6', '6', '10-03-2020', 'Feb-03-2017', null);
INSERT INTO `products` VALUES ('70', 'Queen Golden Rings', 'GR', ' Quality product UAE', 'images.jpg', 'Earings', '', '20000', '50000', '30000', 'Turkey deallers', '0', '4', '6', 'Feb-03-2087', 'Feb-03-2017', '1');
INSERT INTO `products` VALUES ('71', 'Blink Triangel Rings', 'BT', ' shiny and Clare products from Kenya', 'images3.jpg', 'Earings', '', '20000', '90000', '70000', 'Seven Seas suppliers', '0', '7', '7', 'Feb-03-2047', 'Feb-03-2017', '2');
INSERT INTO `products` VALUES ('73', 'Nevea spray', 'NS', ' All size and quantity available ', 'mary-kay.jpg', 'Perfumes', '', '300', '450', '150', 'Turkey deallers', '0', '119', '120', 'Feb-03-2045', 'Feb-03-2017', '1');
INSERT INTO `products` VALUES ('74', 'Ferrari Spray Products', 'FS', ' Products from Dubai ', 'ferrari perfume.jpg', 'Perfumes', '', '500', '1200', '700', 'Seven Seas suppliers', '0', '7', '50', 'Feb-03-2037', 'Feb-03-2017', '2');

-- ----------------------------
-- Table structure for `purchases`
-- ----------------------------
DROP TABLE IF EXISTS `purchases`;
CREATE TABLE `purchases` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `suplier` varchar(100) NOT NULL,
  `remarks` varchar(100) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of purchases
-- ----------------------------

-- ----------------------------
-- Table structure for `purchases_item`
-- ----------------------------
DROP TABLE IF EXISTS `purchases_item`;
CREATE TABLE `purchases_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `cost` varchar(100) NOT NULL,
  `invoice` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of purchases_item
-- ----------------------------

-- ----------------------------
-- Table structure for `questionnaire`
-- ----------------------------
DROP TABLE IF EXISTS `questionnaire`;
CREATE TABLE `questionnaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `q1` varchar(255) DEFAULT NULL,
  `q2` varchar(255) DEFAULT NULL,
  `q3` varchar(255) DEFAULT NULL,
  `q4` varchar(255) DEFAULT NULL,
  `q5` varchar(255) DEFAULT NULL,
  `q6` varchar(255) DEFAULT NULL,
  `q7` varchar(255) DEFAULT NULL,
  `q8` varchar(255) DEFAULT NULL,
  `q9` varchar(255) DEFAULT NULL,
  `q10` varchar(255) DEFAULT NULL,
  `q11` varchar(255) DEFAULT NULL,
  `q12` varchar(255) DEFAULT NULL,
  `q13` varchar(255) DEFAULT NULL,
  `q14` varchar(255) DEFAULT NULL,
  `q15` varchar(255) DEFAULT NULL,
  `q16` varchar(255) DEFAULT NULL,
  `q17` varchar(255) DEFAULT NULL,
  `q18` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of questionnaire
-- ----------------------------
INSERT INTO `questionnaire` VALUES ('1', 'yes', 'No', 'rarely', '5hrs', 'rarely', 'not-really', 'yes', 'not-really', 'rarely', 'some-how-easy', 'no', 'not-really', 'responsivenes', 'grocery', 'Jumia', 'dislike', 'Male', 'middle-age');
INSERT INTO `questionnaire` VALUES ('2', 'yes', 'No', 'to-some-extended', '10hrs', 'no', 'rarely', 'not-really', 'not-really', 'rarely', 'some-how-easy', 'yes', 'not-really', 'responsivenes', 'grocery', 'debonairs', 'dislike', 'Male', 'middle-age');
INSERT INTO `questionnaire` VALUES ('3', 'yes', 'yes', 'to-some-extended', '10hrs', 'rarely', 'rarely', 'not-really', 'no', 'no', 'yes', 'no', 'no', 'responsivenes', 'grocery', 'Jumia', 'dislike', 'Female', 'youth');
INSERT INTO `questionnaire` VALUES ('4', 'yes', 'No', 'rarely', '10hrs', 'rarely', 'not-really', 'yes', 'no', 'no', 'some-how-easy', 'yes', 'not-really', 'responsivenes', 'furniture', '', 'difficult', 'Female', 'middle-age');
INSERT INTO `questionnaire` VALUES ('5', 'yes', 'yes', 'never', '3hrs', 'yes', 'yes', 'yes', 'no', 'not-really', 'some-how-easy', 'no', 'not-really', 'responsivenes', 'grocery', 'amazon', 'like', 'Female', 'middle-age');
INSERT INTO `questionnaire` VALUES ('6', 'yes', 'yes', 'regular', '', 'no', '', '', '', '', 'yes', '', '', '', '', 'ALL', 'difficult', '', '');
INSERT INTO `questionnaire` VALUES ('7', 'yes', 'yes', 'regular', '', 'no', '', '', '', '', 'yes', '', '', '', '', 'ALL', 'difficult', '', '');
INSERT INTO `questionnaire` VALUES ('8', 'yes', 'yes', 'regular', '', 'no', '', '', '', '', 'yes', '', '', '', '', 'ALL', 'difficult', '', '');
INSERT INTO `questionnaire` VALUES ('9', 'yes', 'No', 'never', '10hrs', 'no', 'rarely', 'not-really', 'no', 'no', 'yes', 'no', 'no', 'reliability', 'furniture', 'ALL', 'difficult', 'Female', 'middle-age');
INSERT INTO `questionnaire` VALUES ('10', '', '', 'to-some-extended', '', 'rarely', '', '', '', '', '', 'yes', '', '', 'grocery', '', '', '', '');
INSERT INTO `questionnaire` VALUES ('11', 'yes', 'No', '', '', '', '', 'not-really', '', '', 'yes', '', '', '', '', '', 'difficult', '', '');
INSERT INTO `questionnaire` VALUES ('12', '', 'yes', '', '', '', '', '', 'no', '', '', '', 'no', '', '', '', 'difficult', '', 'aging');

-- ----------------------------
-- Table structure for `sales`
-- ----------------------------
DROP TABLE IF EXISTS `sales`;
CREATE TABLE `sales` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_number` varchar(100) NOT NULL,
  `cashier` varchar(100) NOT NULL,
  `date` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `due_date` varchar(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `balance` varchar(100) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sales
-- ----------------------------
INSERT INTO `sales` VALUES ('1', 'RS-230323', 'Glady cherotich', '02/06/17', 'cash', '2892.5', '1267.5', '3000', '', '');
INSERT INTO `sales` VALUES ('2', 'RS-0300380', 'Glady cherotich', '02/06/17', 'cash', '6300', '2625', '6300', '', '');
INSERT INTO `sales` VALUES ('3', 'RS-4233202', 'Glady cherotich', '02/20/17', 'cash', '890', '390', '1000', '', '');
INSERT INTO `sales` VALUES ('4', 'RS-623363', 'Glady cherotich', '03/20/17', 'cash', '1200', '500', '1200', '', '');
INSERT INTO `sales` VALUES ('5', 'RS-700048', 'admin', '04/16/17', 'cash', '890', '390', '1', '', '');
INSERT INTO `sales` VALUES ('6', 'RS-973623', 'admin', '04/16/17', 'cash', '2400', '1400', '2400', '', '');
INSERT INTO `sales` VALUES ('7', 'RS-03082820', 'admin', '04/17/17', 'cash', '1200', '700', '1200', '', '');
INSERT INTO `sales` VALUES ('8', 'RS-242520', 'admin', '04/17/17', 'cash', '450', '150', '450', '', '');
INSERT INTO `sales` VALUES ('9', 'RS-032302', 'admin', '05/14/17', 'cash', '30000', '15000', '30000', '', '');
INSERT INTO `sales` VALUES ('10', 'RS-433272', 'admin', '05/17/17', 'cash', '100000', '60000', '100000', '', '');

-- ----------------------------
-- Table structure for `sales_order`
-- ----------------------------
DROP TABLE IF EXISTS `sales_order`;
CREATE TABLE `sales_order` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice` varchar(100) NOT NULL,
  `product` varchar(100) NOT NULL,
  `imgUrl` varchar(100) DEFAULT NULL,
  `qty` varchar(100) NOT NULL,
  `amount` varchar(100) NOT NULL,
  `profit` varchar(100) NOT NULL,
  `product_code` varchar(150) NOT NULL,
  `gen_name` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `price` varchar(100) NOT NULL,
  `discount` varchar(100) NOT NULL,
  `date` varchar(500) NOT NULL,
  PRIMARY KEY (`transaction_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of sales_order
-- ----------------------------
INSERT INTO `sales_order` VALUES ('1', 'RS-230323', '62', 'Gel eyeliner.jpg', '3.25', '2892.5', '1267.5', 'Gel Eyeliner', 'GE', 'For softening the skins. All type and colors available ', '890', '', '02/06/17');
INSERT INTO `sales_order` VALUES ('2', 'RS-0300380', '63', 'Gel eyeliner.jpg', '5.25', '6300', '2625', 'Skins Brushes', 'SB', ' All size and shape available', '1200', '', '02/06/17');
INSERT INTO `sales_order` VALUES ('4', 'RS-4233202', '62', 'Gel eyeliner.jpg', '1', '890', '390', 'Gel Eyeliner', 'GE', 'For softening the skins. All type and colors available ', '890', '', '02/20/17');
INSERT INTO `sales_order` VALUES ('5', 'RS-623363', '63', 'professional Quality Brushes.jpg', '1', '1200', '500', 'Skins Brushes', 'SB', ' All size and shape available', '1200', '', '03/20/17');
INSERT INTO `sales_order` VALUES ('6', 'RS-700048', '62', 'Gel eyeliner.jpg', '1', '890', '390', 'Gel Eyeliner', 'GE', 'For softening the skins. All type and colors available ', '890', '', '04/16/17');
INSERT INTO `sales_order` VALUES ('7', 'RS-973623', '74', 'ferrari perfume.jpg', '2', '2400', '1400', 'Ferrari Spray Products', 'FS', ' Products from Dubai', '1200', '', '04/16/17');
INSERT INTO `sales_order` VALUES ('9', 'RS-03082820', '74', 'ferrari perfume.jpg', '1', '1200', '700', 'Ferrari Spray Products', 'FS', ' Products from Dubai', '1200', '', '04/17/17');
INSERT INTO `sales_order` VALUES ('10', 'RS-242520', '73', 'mary-kay.jpg', '1', '450', '150', 'Nevea spray', 'NS', ' All size and quantity available ', '450', '', '04/17/17');
INSERT INTO `sales_order` VALUES ('11', 'RS-032302', '67', 'Silver Metal Green and Blue Glass.jpg', '2', '30000', '15000', 'Silver Necklace', 'SN', ' Import from dubai .Original products', '15000', '', '05/14/17');
INSERT INTO `sales_order` VALUES ('12', 'RS-433272', '70', 'images.jpg', '2', '100000', '60000', 'Queen Golden Rings', 'GR', ' Quality product UAE', '50000', '', '05/17/17');

-- ----------------------------
-- Table structure for `supliers`
-- ----------------------------
DROP TABLE IF EXISTS `supliers`;
CREATE TABLE `supliers` (
  `suplier_id` int(11) NOT NULL AUTO_INCREMENT,
  `suplier_name` varchar(100) NOT NULL,
  `suplier_address` varchar(100) NOT NULL,
  `suplier_contact` varchar(100) NOT NULL,
  `contact_person` varchar(100) NOT NULL,
  `note` varchar(500) NOT NULL,
  PRIMARY KEY (`suplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of supliers
-- ----------------------------
INSERT INTO `supliers` VALUES ('7', 'Turkey deallers', 'Taita Hills road', 'Mr Sigh', '1234567890', 'Authorized Turkey beauty products');
INSERT INTO `supliers` VALUES ('8', 'Seven Seas suppliers', 'Wundanyi Center, Border Road', 'Chelsea Cherotich', '987654321', 'Come all and experience best beauty products from china');
INSERT INTO `supliers` VALUES ('9', 'Turbo and Herbal beauty products', 'Mtito Center, East isavo Game reserve', 'Madam Beauty', '2345675432', 'Home of beauty, beauty of beauty');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) CHARACTER SET latin1 NOT NULL,
  `password` varchar(100) CHARACTER SET latin1 NOT NULL,
  `name` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `position` varchar(100) CHARACTER SET latin1 NOT NULL DEFAULT 'customer',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=macce;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('3', 'admin', 'admin', 'admin', 'admin@gmail.com', 'admin');
INSERT INTO `user` VALUES ('9', 'boss', '1234', 'Festus', 'festo782@gmail.com', 'customer');
INSERT INTO `user` VALUES ('10', 'festo', '1234', 'festo', 'festo782@gmail.com', 'supplier');
