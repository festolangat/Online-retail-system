<!-- Modal -->
<div class="modal fade" id="checkout_modal" role="dialog">
    <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title" id="myModalLabel"><i class="fa fa-shopping-cart text-success fa-lg"></i> Check Out<small class='text-primary'> Billing Information</small></h4>
      </div>
      <div class="modal-body">
        <form action="cart/data.php?q=checkout" method="POST">
			<input type="hidden" name="totals" class="form-control" value="<?php echo number_format($total,2) ?>" >
            <div class="form-group">
                <label>Firstname</label>
                <input type="text" name="fname" class="form-control" placeholder="(ex. Example)" required>
            </div>
            <div class="form-group">
                <label>Lastname</label>
                <input type="text" name="lname" class="form-control" placeholder="(ex. Example)" required>
            </div>
            <div class="form-group">
                <label>Contact #</label>
                <input type="text" name="contact" class="form-control" placeholder="(ex. 0701xxx**)" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" placeholder="(ex. username@yourdomain.com)" class="form-control">
            </div>
            <div class="form-group">
                <label>Complete Address</label>
                <input type="text" name="address" class="form-control" placeholder="(ex. P.O Box 100-00100, Voi Street)" required>
            </div>
            <div class="alert alert-info">
                Mode of Payment: <strong>Pay on Delivery</strong> <br> *** Please wait for our call/text or email for confirmation. Thank You! ***
            </div>
			
			<div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
       <button type="submit" class="btn btn-success">Submit</button>
		<!--  <a href="#" type="submit" class="btn btn-success btn-lg" data-toggle="modal" data-target="#survey_modal">Submit</a>-->
          </form>
      </div>
            
      </div>
      
    </div>
  </div>
</div>

<!----Login Modal start----->
<div class="modal fade" id="login_modal" role="dialog">
    <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h4 class="modal-title"  id="myModalLabel"><i class="fa fa-filter text-success fa-lg"></i> Kindly enter the following details<small class='text-primary'> </small></h4>
      </div>
      <div class="modal-body">
        <form action="login.php" method="POST">
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" class="form-control" placeholder="I.e Example" required>
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="i.e Example" required>
            </div>
            
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-success">Submit</button>
          </form>
      </div>
    </div>
  </div>
</div>

<!----Survey start----->
<div class="modal fade" id="survey_modal" role="dialog">
    <div class="modal-dialog modal-sm">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
        <h5 class="modal-title" class="btn btn-primary" id="myModalLabel">Kindly help to complete this survey . This survey is meant to capture what different people understand about, e-commerce. Please select what applies to you. <small class='text-primary'> </small></h5>
      </div>
      <div class="modal-body">
        <form action="login.php" method="POST">
            <div class="form-group">
				<span> 1 &nbsp;<span><label class='text-primary'>Do you know any purchasing platform such as Jumia, Amazon,OLZ etc </label>	
				<input type="radio" class="flat" name="yes"  value="yes" />Yes
				<input type="radio" class="flat" name="no"  value="cloths" />No	<br/>
				<span> 2 &nbsp;<span><label class='text-primary'>Have you ever use any of this platform i.e Jumia, Amazon,OLZ etc </label>	
				<input type="radio" class="flat" name="yes"  value="yes"  />Yes
				<input type="radio" class="flat" name="no"  value="cloths" />No	<br/>
				<span> 3 &nbsp;<span><label class='text-primary'>How often do you make purchase online? </label>	
				<input type="radio" class="flat" name="regular"  value="regular"  />Regular
				<input type="radio" class="flat" name="rarely"  value="rarely" />Rarely
				<input type="radio" class="flat" name="to-some-extended"  value="to-some-extended"/>To some extended
				<input type="radio" class="flat" name="never"  value="never" />Never<br/>
                <span> 4 &nbsp;<span><label class='text-primary'>How long do you spent online a day? </label>
				<input type="radio" name="3hrs"  value="3hrs" class="flat" />3hrs and bellow 
				<input type="radio" name="5hrs"  value="5hrs" class="flat" /> 5-8hrs
				<input type="radio" name="10hrs"  value="10hrs" class="flat" />10hrs and above<br />
				<span> 5 &nbsp;<span><label class='text-primary'>I know what to look for when going  online </label>
				<input type="radio" name="yes"  value="yes" class="flat" />Yes
				<input type="radio" name="not-really"  value="not-really" class="flat" /> Not really
				<input type="radio" name="rarely"  value="rarely" class="flat" />Rarely
				<input type="radio" name="no"  value="no" class="flat" />No<br />
				<span> 6 &nbsp;<span><label class='text-primary'>I seek guidance on how to you use online platform</label>
				<input type="radio" name="yes"  value="yes" class="flat" />Yes
				<input type="radio" name="not-really"  value="not-really" class="flat" /> Not really
				<input type="radio" name="rarely"  value="rarely" class="flat" />Rarely
				<input type="radio" name="no"  value="no" class="flat" />No<br />
				<span> 7 &nbsp;<span><label class='text-primary'>Online purchasing is the easiest methods of making orders. </label>	
				<input type="radio" name="yes"  value="yes" class="flat" />Yes
				<input type="radio" name="not-really"  value="not-really" class="flat" /> Not really
				<input type="radio" name="complicate"  value="complicate" class="flat" />Complicate
				<input type="radio" name="no"  value="no" class="flat" />No<br />
				<span> 8 &nbsp;<span><label class='text-primary'>Online purchaisng is too complicate platform </label>
				<input type="radio" name="yes"  value="yes" class="flat" />Yes
				<input type="radio" name="not-really"  value="not-really" class="flat" /> Not really				
				<input type="radio" name="no"  value="no" class="flat" />No<br />
				<span> 9 &nbsp;<span><label class='text-primary'>I find better deals when using online </label>
				<input type="radio" name="yes"  value="yes" class="flat" />Yes
				<input type="radio" name="not-really"  value="not-really" class="flat" /> Not really
				<input type="radio" name="rarely"  value="rarely" class="flat" />Rarely
				<input type="radio" name="no"  value="no" class="flat" />No<br />
				<span> 10 &nbsp;<span><label class='text-primary'>It is very easy to locate a product when using online platform</label>
				<input type="radio" name="yes"  value="yes" class="flat" />Yes
				<input type="radio" name="some-how-easy"  value="some-how-easy" class="flat" /> Some how Easy
				<input type="radio" name="difficult"  value="difficult" class="flat" />Difficult
				<input type="radio" name="some-how-difficult"  value="some-how-difficult" class="flat" /> Some how Difficult<br />
				<span> 11 &nbsp;<span><label class='text-primary'>Online purchase is the most reliable method of buying products</label>
				<input type="radio" class="flat" name="yes"  value="yes" />Yes
				<input type="radio" class="flat" name="no"  value="no" />No<br/>
				<span> 12 &nbsp;<span><label class='text-primary'>I do understand the risk with the use of online platform </label>
				<input type="radio" class="flat" name="yes"  value="yes"  />Yes
				<input type="radio" name="not-really"  value="not-really" class="flat" /> Not really
				<input type="radio" class="flat" name="no"  value="no" />No<br/>
				<span> 13 &nbsp;<span><label class='text-primary'>What do you like most like most with the use online purchasing</label><br/>
				<input type="radio" name="responsivenes"  value="responsivenes" class="flat" />Responsivenes
				<input type="radio" name="reliability"  value="reliability" class="flat" /> Reliability
				<input type="radio" name="conveniency"  value="conveniency" class="flat" /> Conveniency<br/>
				<span> 14 &nbsp;<span><label class='text-primary'>Which products do you mostly buy online </label>
				<input type="radio" class="flat" name="electronics"  value="electronics"  />Electronics
				<input type="radio" class="flat" name="cloths"  value="cloths" />Cloths
				<input type="radio" class="flat" name="Grocery"  value="grocery" />grocery
				<input type="radio" class="flat" name="furniture"  value="furniture" />Furnitures
				<input type="radio" class="flat" name="hair"  value="salon" />Hair products<br/>				
				<span> 15 &nbsp;<span><label class='text-primary'>Have use this online platform to purchase products </label>
				<input type="checkbox" name="amazon"  value="amazon" class="flat" />Amazon
				<input type="checkbox" name="OLX"  value="olz" class="flat" />Jumia
				<input type="checkbox" name="debonair "  value="debonair" class="flat"/>OLZ
				<input type="checkbox" name="all"  value="all" class="flat" />Debonairs Pizza
				<input type="checkbox" name="none"  value="none" class="flat" /> 	All
				<input type="checkbox" name="none"  value="none" class="flat" /> None<br/>
				<span> 16 &nbsp;<span><label class='text-primary'>My first experence with the use of online platform</label>
				<input type="radio" class="flat" name="like"  value="like" />I like it
				<input type="radio" class="flat" name="dislike"  value="dislike" />Dislike
				<input type="radio" class="flat" name="difficult"  value="difficult" />very difficult<br/>					
				<span> 17 &nbsp;<span><label class='text-primary'>My gender</label> 
				<input type="radio" class="flat" name="gender"  value="M"  />Male
				<input type="radio" class="flat" name="gender" id="genderF" value="F" />Female<br/>
				<span> 18 &nbsp;<span><label class='text-primary'>My age bracket</label>
				<input type="radio" name="youth"  value="youth" class="flat" />25yrs bellow 
				<input type="radio" name="middle-age"  value="middle-age" class="flat" /> 26-35yrs
				<input type="radio" name="old-age"  value="old-age" class="flat" />36-50yrs
				<input type="radio" name="age"  value="age" class="flat" />51yrs above 				
            </div>
            
      </div>
      <div class="modal-footer">
           <button type="submit" class="btn btn-success">Submit</button>
          </form>
      </div>
    </div>
  </div>
</div>
