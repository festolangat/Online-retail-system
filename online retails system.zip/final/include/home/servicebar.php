<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<div class="list-group">
		<a href="#" class="list-group-item active">CATEGORIES</a>
		</div>
                        <div class="list-group">
                        <?php                            
                            $sql = "Select * from bookcategory order by name asc";
                            $r = mysql_query($sql);

                            if($r){
                                while($row = mysql_fetch_array($r)){
                                    echo '<a href="service-category.php?filter='.$row['name'].'" class="list-group-item">'.$row['name'].'</a>';
                                }
                            }
                        ?>                    
                        </div> 
                        <!--/category-products-->
                        </div>
                        </div>