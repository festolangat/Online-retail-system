<?php
session_start();
include('../connect.php');
$id=$_POST['memi'];
$a = $_POST['name'];
// query
$sql = "UPDATE m_order 
        SET status=?
		WHERE id='$id'";
$q = $db->prepare($sql);
$q->execute(array($a));
header("location: orders.php");
?>