<?php
session_start();
include('../connect.php');
$a = $_POST['name'];
$b = $_POST['email'];
$c = $_POST['uname'];
$d = $_POST['password'];

// query
$sql = "INSERT INTO user (username,password,name,email) VALUES (:c,:d,:a,:b)";
$q = $db->prepare($sql);
$q->execute(array(':c'=>$c,':d'=>$d,':a'=>$a,':b'=>$b));
header("location: users_profile.php");


?>