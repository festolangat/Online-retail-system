<?php
	include('../connect.php');
	$id=$_GET['id'];
	$result = $db->prepare("SELECT * FROM m_order WHERE id= :userid");
	$result->bindParam(':userid', $id);
	$result->execute();
	for($i=0; $row = $result->fetch(); $i++){
?>
<link href="../style.css" media="screen" rel="stylesheet" type="text/css" />
<form action="save_edit_order.php" method="post">
<center><h4><i class="icon-edit icon-large"></i> Update Transaction</h4></center>
<hr>
<div id="ac">
<input type="hidden" name="memi" value="<?php echo $id; ?>" />
<span>statuis : </span><select name="name" style="width:265px; height:30px;" value="<?php echo $row['name']; ?>">
<option> Processing</option>
<option> On-Transit</option>
<option> Decline</option>
<option> Processing</option>
</select>
<br>

<div style="float:right; margin-right:10px;">

<button class="btn btn-success btn-block btn-large" style="width:267px;"><i class="icon icon-save icon-large"></i> Update</button>
</div>
</div>
</form>
<?php
}
?>