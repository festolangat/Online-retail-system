<?php
session_start();
include('../connect.php');
$a = $_POST['category'];

// query
$sql = "INSERT INTO category (title) VALUES (:a)";
$q = $db->prepare($sql);
$q->execute(array(':a'=>$a));
header("location: products.php");


?>