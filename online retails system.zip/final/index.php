<?php include('include/home/header.php'); ?>
    	<section>
		<div class="container">
			<div class="row">
				<?php include('include/home/sidebar.php'); ?>
    <div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<div class="list-group">
		<center><a href="#" class="list-group-item active">ALL PRODUCTS</a></center>
		</div>
		<ul  class="col-sm-12">
		<?php include('include/home/slider.php')?>
		</ul>
</div>
</div>
</div>
</section>

<?php include('include/home/modal.php'); ?>
<?php include('include/home/footer.php'); ?>
