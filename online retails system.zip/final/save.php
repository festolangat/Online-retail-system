 <?php include ('db.php'); ?>
	 <?php
	//Parse the form data and add product to the system
	 if(isset($_POST['submit'])){
	$fname=mysql_real_escape_string($_POST['fname']);
	$email=mysql_real_escape_string($_POST['email']);
	$uname=mysql_real_escape_string($_POST['uname']);
	$password=mysql_real_escape_string($_POST['password']);
	////Add message into the database
					$sql = mysql_query("INSERT INTO user(username, password, name, email) VALUES('$uname', '$password', '$fname', '$email')") or die (mysql_error());
					 header("location: index.php?=New record added Details register successful!");
					}
	 ?>
	 