<?php
	include("db.php");
	
	$prodID = $_GET['prodid'];

	if(!empty($prodID)){
		$sqlSelectSpecProd = mysql_query("select * from products where product_id = '$prodID'") or die(mysql_error());
		$getProdInfo = mysql_fetch_array($sqlSelectSpecProd);
		$prodcode= $getProdInfo["product_code"];
		$prodcat = $getProdInfo["category"];
		$prodprice = $getProdInfo["price"];
		$proddesc = $getProdInfo["gen_name"];
		$prodimage = $getProdInfo["imgUrl"];
		$prodsupplier = $getProdInfo["supplier"];
		$prodname = $getProdInfo["product_name"];
		$view = $getProdInfo["view"];
				
			//update view count
				$count=$view+1;
				$sql=mysql_query("Update products set view=".$count." where product_id = '$prodID' ");
				$scan=mysql_query("select * from products where product_id = '$prodID'");
				$getview = mysql_fetch_array($scan);
				$views=$getview["view"];
				}
?>
<?php include('include/home/header.php'); ?>

	<section>
		<div class="container">
			<div class="row">
				<?php include('include/home/sidebar.php'); ?>
				
                
				<div class="col-sm-9 padding-right">
					<div class="product-details"><!--product-details-->
						<div class="col-sm-5">
							<div class="view-product">
                            
						
							<img src="reservation/img/products/<?php echo $prodimage; ?>" />	
                                
							</div>
						</div>
						<div class="col-sm-7">
							<div class="product-information"><!--/product-information-->
							<h2 class="product"><?php echo $prodcode; ?></h2>
								<p>Description: <?php echo $prodname; ?></p>
								<p>Category: <?php echo $prodcat; ?></p>								
								<p>Supplier: <?php echo $prodsupplier; ?></p>				
								<p>Price: <span class="price"><?php echo $prodprice; ?></span></p>

								<p>Views: <?php echo $views; ?></p>
                                
                               <a  class="btn btn-default add-to-cart" id="add-to-cart"><i class="fa fa-shopping-cart"></i>Add to Cart</a>
                                <p class="info hidethis" style="color:red;"><strong>Product Added to Cart!</strong></p>
								<p><b>Type: </b><?php echo $proddesc; ?></p>
								<p><b>Contact Info:</b> +254-700-751-519</p>
								<p><b>Email:</b> chelsea@gmail.com</p>
								
							</div><!--/product-information-->
						</div>
					</div><!--/product-details-->
					
				</div>
			</div>
		</div>
		</div>
	</section>
	
	<?php include('include/home/footer.php'); ?>