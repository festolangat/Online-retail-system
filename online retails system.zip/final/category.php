<?php include('include/home/header.php'); ?>

    	<section>
		<div class="container">
			<div class="row">
				<?php include('include/home/sidebar.php'); ?>
                <?php $filter = isset($_GET['filter']) ? $_GET['filter'] : '';?>
                    
    <div class="col-sm-9 padding-right">
					<div class="features_items"><!--features_items-->
						<h2 class="title text-center">Some of  <?php echo $filter;?> Product available</h2>
            <br>
	
<!--php starts here-->
<?php											
					$result = mysql_query("SELECT * FROM products where product_code like '%$filter%' or gen_name like '%$filter%' or category like '%$filter%'");
                    

				if($result){				
				while($row=mysql_fetch_array($result)){
					
				$prodID = $row["product_id"];	
					echo '<ul class="col-sm-4">';
					echo '<div class="product-image-wrapper">
						  <div class="single-products">
						  <div class="productinfo text-center">
					<a href="product-details.php?prodid='.$prodID.'" rel="bookmark" title="'.$row['product_code'].'"><img src="reservation/img/products/'.$row['imgUrl'].'" alt="'.$row['product_code'].'" title="'.$row['product_code'].'" width="150" height="150" />
                    </a>
					
					<h2><a href="product-details.php?prodid='.$prodID.'" rel="bookmark" title="'.$row['product_code'].'">'.$row['product_code'].'</a></h2>
					<h2>'.$row['price'].'</h2>
					<p>Category: '.$row['category'].'</p>
					
					<a href="product-details.php?prodid='.$prodID.'" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>View Details</a>
					</div>';		
					echo '</ul>';			
				}
				}
				?>

<!--php ends here-->
		</div>
        </div>
</div>
</div>
</div>
</section>

<?php include('include/home/footer.php'); ?>