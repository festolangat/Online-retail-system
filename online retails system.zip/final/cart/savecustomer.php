<?php
session_start();

include ('../db.php');
	 
	//Parse the form data and add product to the system
	 if(isset($_POST['submit'])){
	$fname=mysql_real_escape_string($_POST['fname']);
	$email=mysql_real_escape_string($_POST['email']);
	$usname=mysql_real_escape_string($_POST['usname']);
	$password=mysql_real_escape_string($_POST['password']);
	////Add message into the database
					$sql = mysql_query("INSERT INTO user(username, password, name, email, position) VALUES('$usname', '$password', '$name', '$email')") or die (mysql_error());
					}


?>