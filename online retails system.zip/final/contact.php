<?php include('include/home/header.php'); ?>
	 <?php include ('db.php'); ?>
	 <?php
	//Parse the form data and add product to the system
	 if(isset($_POST['submit'])){
	$name=mysql_real_escape_string($_POST['name']);
	$email=mysql_real_escape_string($_POST['email']);
	$subject=mysql_real_escape_string($_POST['subject']);
	$message=mysql_real_escape_string($_POST['message']);
	////Add message into the database
					$sql = mysql_query("INSERT INTO message(name, email, subject, message, date_added) VALUES('$name', '$email', '$subject', '$message', now())") or die (mysql_error());
					header("location: index.php?Message sent successful!");
					}
	 ?>
	 <div id="contact-page" class="container">
	 
    	<div class="bg">
	    	<div class="row">  			
	    		<div class="col-sm-12"> 				
					<div class="list-group">
                               <center><a href="#" class="list-group-item active">CONTACT US</a></center>
                            </div>    			    				    				
					
				</div>			 		
			</div> 
				<?php include('include/home/sidebar.php'); ?>
                <?php $filter = isset($_GET['filter']) ? $_GET['filter'] : '';?>			
    		<div class="row">  	
	    		<div class="col-sm-8">
	    			<div class="contact-form">
	    				<div class="status alert alert-success" style="display: none"></div>
				    	<form id="main-contact-form" class="contact-form row" name="contact-form" method="post" action="contact.php">
				            <div class="form-group col-md-6">
				                <input type="text" name="name" class="form-control" required placeholder="Enter your Name">
				            </div>
				            <div class="form-group col-md-6">
				                <input type="email" name="email" class="form-control" required placeholder="Enter your Email Address">
				            </div>
				            <div class="form-group col-md-12">
				                <input type="text" name="subject" class="form-control" required placeholder="Enter the Subject">
				            </div>
				            <div class="form-group col-md-12">
				                <textarea name="message" id="message" required class="form-control" rows="8" placeholder="Your Message Here"></textarea>
				            </div>                        
				            <div class="form-group col-md-12">
				                <input type="submit" name="submit" class="btn btn-primary pull-left" value="Submit">
				            </div>
				        </form>
	    			</div>
	    		</div>   			
	    	</div>  
    	</div>	
    </div><!--/#contact-page-->
	<?php include('include/home/footer.php'); ?>