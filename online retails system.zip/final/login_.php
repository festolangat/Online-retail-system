
<?php include('include/home/header.php'); ?>

	 <div id="contact-page" class="container">
	 
    	<div class="bg">
	    	<div class="row">  			
	    		<div class="col-sm-12"> 				
					<div class="list-group">
                               <center><a href="#" class="list-group-item active"> <i class="fa fa-unlock-alt text-success fa-lg"></i>Enter your credential</a></center>
                            </div>    			    				    				
					
				</div>			 		
			</div> 
				<?php include('include/home/sidebar.php'); ?>
                <?php $filter = isset($_GET['filter']) ? $_GET['filter'] : '';?>			
    		<div class="row">  	
	    		<div class="col-sm-8">
	    			<div class="contact-form">
	    				<div class="status alert alert-success" style="display: none"></div>
				    	<form id="main-contact-form" class="contact-form row" name="contact-form" method="post" action="login.php" >
				            <div class="form-group col-md-6">
				                <input type="text" name="username" class="form-control" required placeholder="Enter the Username">
				            </div>
				            
							<div class="form-group col-md-6">
				                <input type="password" name="password" class="form-control" required placeholder="Enter the Password">
				            </div>							
				            <div class="form-group col-md-12">
				                <input type="submit" name="submit" class="btn btn-primary pull-left" value="Submit">
				            </div>
				        </form>
	    			</div>
	    		</div>   			
	    	</div>  
    	</div>	
    </div><!--/#contact-page-->
	<?php include('include/home/footer.php'); ?>